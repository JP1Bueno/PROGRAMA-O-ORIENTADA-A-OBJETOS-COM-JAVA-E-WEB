package model;

import java.sql.Date;

public class Ingresso {
	private int id;
    private int showId;
    private int clienteId;
    private int quantidade;
    private Date dataCompra;

    public Ingresso(int showId, int clienteId, int quantidade) {
        this.showId = showId;
        this.clienteId = clienteId;
        this.quantidade = quantidade;
        this.dataCompra = new Date(System.currentTimeMillis());
    }

    public Ingresso() {} // Construtor vazio

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getShowId() {
        return showId;
    }

    public void setShowId(int showId) {
        this.showId = showId;
    }

    public int getClienteId() {
        return clienteId;
    }

    public void setClienteId(int clienteId) {
        this.clienteId = clienteId;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public Date getDataCompra() {
        return dataCompra;
    }

    public void setDataCompra(Date dataCompra) {
        this.dataCompra = dataCompra;
    }
}
