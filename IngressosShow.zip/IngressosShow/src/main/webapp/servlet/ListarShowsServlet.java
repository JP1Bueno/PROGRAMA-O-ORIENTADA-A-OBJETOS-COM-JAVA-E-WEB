package servlet;

import dao.ShowDAO;
import model.Show;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/listarShows")
public class ListarShowsServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ShowDAO showDAO = new ShowDAO();
        try {
            List<Show> shows = showDAO.listar(); // Obtém a lista de shows
            request.setAttribute("shows", shows); // Define a lista como atributo da requisição
        } catch (SQLException e) {
            e.printStackTrace(); // Lida com exceção de SQL
            request.setAttribute("errorMessage", "Erro ao listar shows."); // Mensagem de erro
        }
        // Encaminha a requisição para a página JSP estilizada
        RequestDispatcher dispatcher = request.getRequestDispatcher("jsp/showList.jsp");
        dispatcher.forward(request, response);
    }
}
