package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {
	private static final String URL = "jdbc:oracle:thin:@oracle.fiap.com.br:1521:ORCL"; // Seu host name
    private static final String USER = "rm98825"; // Substitua pelo seu usuário
    private static final String PASSWORD = "160305"; // Substitua pela sua senha

    
	public static Connection getConnection() {
		try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException("Erro ao conectar ao banco de dados", e);
        } 
		
	}
}
