package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Ingresso;

public class IngressoDAO {
	private Connection connection;

    public IngressoDAO() {
        this.connection = ConnectionFactory.getConnection();
    }

    public void adicionar(Ingresso ingresso) throws SQLException {
        String sql = "INSERT INTO Ingresso (cliente_id, show_id, quantidade, data_compra) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, ingresso.getClienteId());
            stmt.setInt(2, ingresso.getShowId());
            stmt.setInt(3, ingresso.getQuantidade());
            stmt.setDate(4, ingresso.getDataCompra());
            stmt.executeUpdate();
        }
    }

    public List<Ingresso> listar() throws SQLException {
        String sql = "SELECT * FROM Ingresso";
        List<Ingresso> ingressos = new ArrayList<>();
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Ingresso ingresso = new Ingresso();
                ingresso.setId(rs.getInt("id"));
                ingresso.setClienteId(rs.getInt("cliente_id"));
                ingresso.setShowId(rs.getInt("show_id"));
                ingresso.setQuantidade(rs.getInt("quantidade"));
                ingresso.setDataCompra(rs.getDate("data_compra"));
                ingressos.add(ingresso);
            }
        }
        return ingressos;
    }
}
