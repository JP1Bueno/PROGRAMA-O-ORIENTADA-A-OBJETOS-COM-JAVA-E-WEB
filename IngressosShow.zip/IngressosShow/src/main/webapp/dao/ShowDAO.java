package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Show;
public class ShowDAO {
	private Connection connection;

    public ShowDAO() {
        this.connection = ConnectionFactory.getConnection();
    }

    public void adicionar(Show show) throws SQLException {
        String sql = "INSERT INTO Show (nome, data, local) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, show.getNome());
            stmt.setDate(2, show.getData());
            stmt.setString(3, show.getLocal());
            stmt.executeUpdate();
        }
    }

    public List<Show> listar() throws SQLException {
        String sql = "SELECT * FROM Show";
        List<Show> shows = new ArrayList<>();
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Show show = new Show();
                show.setId(rs.getInt("id"));
                show.setNome(rs.getString("nome"));
                show.setData(rs.getDate("data"));
                show.setLocal(rs.getString("local"));
                shows.add(show);
            }
        }
        return shows;
    }
}
